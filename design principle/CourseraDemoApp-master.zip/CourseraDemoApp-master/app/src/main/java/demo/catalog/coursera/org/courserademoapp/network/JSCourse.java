package demo.catalog.coursera.org.courserademoapp.network;

public class JSCourse {
    public String id;
    public String name;
    public String shortName;
    public String smallIcon;
}
