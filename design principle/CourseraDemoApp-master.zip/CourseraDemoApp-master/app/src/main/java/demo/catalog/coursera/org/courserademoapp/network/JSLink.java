package demo.catalog.coursera.org.courserademoapp.network;

public class JSLink {
}
