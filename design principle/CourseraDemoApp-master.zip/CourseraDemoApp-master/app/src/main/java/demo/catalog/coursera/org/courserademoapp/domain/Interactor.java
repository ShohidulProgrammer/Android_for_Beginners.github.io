package demo.catalog.coursera.org.courserademoapp.domain;

import rx.Observable;

public interface Interactor {
    public Observable getCourseObservable();
}
