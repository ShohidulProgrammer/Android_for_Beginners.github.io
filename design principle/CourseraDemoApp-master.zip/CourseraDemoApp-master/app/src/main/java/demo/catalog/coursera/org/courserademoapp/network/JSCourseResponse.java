package demo.catalog.coursera.org.courserademoapp.network;

public class JSCourseResponse {
    public JSCourse[] elements;
}
