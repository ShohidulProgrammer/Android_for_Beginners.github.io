package demo.catalog.coursera.org.courserademoapp.di;

import java.lang.annotation.Retention;
import javax.inject.Scope;

@Scope
public @interface ActivityScope {
}