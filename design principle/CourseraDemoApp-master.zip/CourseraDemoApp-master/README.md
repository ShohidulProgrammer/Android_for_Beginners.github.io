# CourseraDemoApp
Demo app to demonstrate creating Android app based on VIPER + MVVM
