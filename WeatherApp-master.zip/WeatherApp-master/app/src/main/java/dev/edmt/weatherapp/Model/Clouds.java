package dev.edmt.weatherapp.Model;

/**
 * Created by reale on 05/10/2016.
 */

public class Clouds {
    private int all;

    public Clouds(int all) {
        this.all = all;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
