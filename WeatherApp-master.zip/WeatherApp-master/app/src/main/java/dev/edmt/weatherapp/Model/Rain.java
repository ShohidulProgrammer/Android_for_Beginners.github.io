package dev.edmt.weatherapp.Model;

/**
 * Created by reale on 05/10/2016.
 */

public class Rain {
}
